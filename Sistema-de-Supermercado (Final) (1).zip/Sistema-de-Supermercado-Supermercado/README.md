# Supermercado - Poo

Sistema de Supermercado em Java feito para aprovação na disciplina de Programação Orientada a Objetos.

O projeto conta com interface Swing, onde é possível fazer:

- Inserção de novos usuários;
- Inserção de novos produtos;
- Vendas;
- Pesquisar por produtos através de palavras;
- Salvar e ler dados do disco;
- Gerar relatórios sobre vendas e estoque.


Bibliotecas externas utilizadas

Utilizadas na classe "CriptografaSenha"
sun.misc.BASE64Decoder;
sun.misc.BASE64Encoder;

Detalhes Técnicos

Ferramenta utilizada para a realização do projeto: Apache NetBeans IDE 15


Diretório para acesso dos arquivos fonte

Sistema_de_Supermercado-Supermercado/src/sistema_de_supermercado

E para execução do arquivo é só dar dois cliques no arquivo .jar (executável)

Descrição do Projeto e Diagrama de Classes são os arquivos .pdf exigidos nos requisitos de avaliação

Participantes: Guilherme Oliveira Santos, André Filipe Fontes Freitas, David Just Valença Júnior
package sistema_de_supermercado;


public class Gerente {
   // private Produto p;
    
    public void addProdutoEmEstoque(){
        
    }
    
    public void removeProdEmEstoque(){
        
    }
    
    public void alteraProduto(){
        
    }
    
    //public void setProduto(Produto p){
        //this.p = p;
    //}
    
    //public Produto getProduto(){
      //  return this.p;
    //}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_de_supermercado;

/**
 *
 * @author Usuário
 */
public class BASE64Encoder {

    public BASE64Encoder() {
    }
    
}

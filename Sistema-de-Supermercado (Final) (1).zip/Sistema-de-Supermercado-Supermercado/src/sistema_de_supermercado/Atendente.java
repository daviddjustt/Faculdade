package sistema_de_supermercado;


public class Atendente {
    private Cliente c;
    
    public void extornaProd(){
        
    }
    
    public void cadastraCompra(){
        
    }
    
    public void setCliente(Cliente c){
        this.c=c;
    }
    
    public Cliente getCliente(){
        return this.c;
    }
}
